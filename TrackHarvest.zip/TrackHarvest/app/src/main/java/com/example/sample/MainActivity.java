package com.example.sample;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Button;
public class MainActivity extends AppCompatActivity{
private Button buttonA;
private Button buttonB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        buttonA = (Button) findViewById(R.id.btn1);
        buttonA.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openTable();
            }
        });
        buttonB = (Button)findViewById(R.id.btn2);
        buttonB.setOnClickListener(new View.OnClickListener() {
            @Override
            public  void onClick(View v){
                openScan();
            }
        });

    }
        public void openTable() {
            Intent intent = new Intent(this, Table.class);
                startActivity(intent);
    }   public void openScan(){
            Intent intent = new Intent(this,Scan.class);
                startActivity(intent);
    }


    }

