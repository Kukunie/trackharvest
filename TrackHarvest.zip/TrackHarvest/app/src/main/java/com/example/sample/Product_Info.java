package com.example.sample;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
public class Product_Info extends AppCompatActivity {

  // private Button productinfo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product__info);
    //    productinfo = (Button) findViewById(R.id.btn3);
     //   productinfo.setOnClickListener(new View.OnClickListener() {
        //    @Override
         //   public void onClick(View v) {
             //   openProduct_Info();
           // }
      //  });
   // }

   // public void openProduct_Info() {
       // Intent intent = new Intent(this, Product_Info.class);
       // startActivity(intent);
    }
}
